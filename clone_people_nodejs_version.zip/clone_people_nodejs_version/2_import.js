const axios = require('axios');
const fs = require('fs');
const { parse } = require('csv-parse/sync');
const { env } = require('process');

require('dotenv').config();


// --- Configuration ---
const API_TOKEN = process.env.API_TOKEN;
const IMPORT_FILE = process.env.IMPORT_FILE;

const TEST_MODE = false;
const BASE_URL = "https://api.peopleware.com";

const headers = {
    'Authorization': `Bearer ${API_TOKEN}`,
    'Content-Type': 'application/json'
};

async function performPost(endpoint, payload, label) {
    if (TEST_MODE) {
        console.log(`   [TEST] Would POST ${label} to ${endpoint}`);
        return { data: { data: { id: "DUMMY_" + Math.floor(Math.random() * 1000) } } };
    }
    return await axios.post(`${BASE_URL}${endpoint}`, { data: payload }, { headers });
}

async function startImport() {
    if (!fs.existsSync(IMPORT_FILE)) {
        console.error(`Fehler: Datei ${IMPORT_FILE} nicht gefunden!`);
        return;
    }

    const fileContent = fs.readFileSync(IMPORT_FILE);
    const records = parse(fileContent, { columns: true, delimiter: ';' });

    for (const row of records) {
        console.log(`\n` + "=".repeat(60));
        console.log(`🚀 Starte Import für: ${row.lastName} (${row.email})`);

        try {
            // 1. Person erstellen (Basis-Record)
            const personResp = await performPost('/people', {
                firstName: row.firstName,
                lastName: row.lastName,
                email: row.email,
                personnelNumber: row.personnelNumber,
                sendMail: process.env.SEND_WELCOME_MAIL === 'true'
            }, "Person");

            const newId = personResp.data.data.id;
            console.log(`✅ Person erstellt (ID: ${newId})`);

            // 2. Mapping & POST der Zuweisungen
            const assignments = [
                { data: JSON.parse(row.json_contracts), path: `/people/${newId}/contract-assignments`, label: "Verträge" },
                { data: JSON.parse(row.json_units), path: `/people/${newId}/planning-unit-memberships`, label: "Planungseinheiten" },
                { data: JSON.parse(row.json_skills), path: `/people/${newId}/skill-level-assignments`, label: "Qualifikationen" },
                { data: JSON.parse(row.json_selectors), path: `/people/${newId}/selection-memberships`, label: "Auswahlen" },
                { data: JSON.parse(row.json_wtp), path: `/people/${newId}/work-time-pattern-model-assignments`, label: "Planungsmodelle" },
                { data: JSON.parse(row.json_shift_seq), path: `/people/${newId}/shift-sequence-assignments`, label: "Schichtfolgen" }
            ];

            for (const group of assignments) {
                for (const item of group.data) {
                    // Mapping-Korrektur (validFrom -> startDate etc.)
                    const payload = { ...item };
                    
                    // Bereinigung des Payloads für den POST
                    if (payload.validFrom) payload.startDate = payload.validFrom;
                    if (payload.validTo) payload.endDate = payload.validTo;
                    if (!payload.priority && group.label === "Units") payload.priority = 1;

                    // Entferne IDs und Metadata aus dem Template-Item
                    delete payload.id;
                    delete payload.skillName; delete payload.skillLevelName; // Skills cleanup
                    delete payload.selectionName; // Selection cleanup
                    delete payload.workTimePatternModelName; // WTP cleanup
                    delete payload.shiftSequenceName; delete payload.shiftSequenceRowName; // Shift cleanup

                    await performPost(group.path, payload, group.label);
                }
                console.log(`   - ${group.label} erfolgreich zugewiesen.`);
            }
            console.log(`🎉 FINISH: ${row.lastName}, ${row.firstName}  vollständig kopiert.`);

        } catch (error) {
            const errorMsg = error.response ? JSON.stringify(error.response.data) : error.message;
            console.error(`❌ Fehler bei ${row.lastName}, ${row.firstName}: ${errorMsg}`);
        }
    }
}

startImport();