PEOPLEWARE PERSON CLONE TOOL  

Dieses Tool kopiert die Daten einer bestehenden Person („Vorlage“) aus Peopleware in eine CSV-Datei. 
Diese kann angepasst werden, um neue Mitarbeiter mit identischen Einstellungen anzulegen.

Was wird kopiert?
* Verträge & Planungseinheiten
* Qualifikationen
* Auswahlen & Planungsmodelle
* Schichtfolgen

#############################
1. Voraussetzungen (Einmalig)
#############################

### --------------------------
### Node.js & npm Installation
### --------------------------

1. Lade die **LTS-Version** (Long Term Support) unter [nodejs.org](https://nodejs.org/) herunter.
2. Führe die `.msi`-Datei aus.
3. **Wichtig:** Aktiviere die Option **"Add to PATH"** (Standardeinstellung).
4. **Prüfung:** Öffne die Windows-Eingabeaufforderung (CMD) und gib `node -v` sowie `npm -v` ein. Beide müssen eine Versionsnummer ausgeben.

### ------------------------------------------
### Einmalige Vorbereitung //Tool-Installation
### ------------------------------------------

1. Kopiere die Skript-Dateien in einen neuen Ordner.
2. Benenne die sample.env Datei in .env um.
3. Öffne die CMD im Ordner: `cd C:\Dein\Pfad\zu\api-scripts`
4. Installiere die Abhängigkeiten: `npm install`

##################################
## 2. Konfiguration (`.env`-Datei)
##################################

Du benötigst einen Personal Access Token
https://help.peopleware.com/api/#authorization-personal-access-token-

Bearbeite die `.env` Datei - passe mindestens die Werte für API_TOKEN und TEMPLATE_PERSON_ID an:

API_TOKEN=dein_persönlicher_token_hier
TEMPLATE_PERSON_ID=123456
IMPORT_FILE=import.csv
SEND_WELCOME_MAIL=false

HINWEISE:
* `TEMPLATE_PERSON_ID`: Die ID der Person, die als Vorlage dient.
* `SEND_WELCOME_MAIL`: `true` oder `false`. Steuert den Mail-Versand an neue Mitarbeiter.
* **Wichtig:** Teile niemals deinen Personal Access Token!

############################
## 3. Nutzung (Der Workflow)
############################

### ----------------------------
### Schritt 1: Daten exportieren
### ----------------------------

Prüfe die TEMPLATE_PERSON_ID in der .env Datei und passe diese ggf. an.

Führe den Export aus, um die Vorlage in die CSV-Datei zu laden:

npm run export

### ----------------------------
### Schritt 2: CSV-Datei anpassen
### ----------------------------

1. Öffne die `import.csv` (z. B. in Excel).
2. Ändere die Spalten `firstName`, `lastName`, `email`, `personnelNumber` für die Vorlagen-Person.
3. Für weitere Mitarbeiter, kopiere die Zeile für die Vorlagen-Person und passe die Spalten `firstName`, `lastName`, `email`, `personnelNumber` entsprechend an.
4. **Wichtig:** Die restlichen JSON-Spalten müssen unverändert bleiben. 
5. Speichere die Datei weiterhin als CSV mit **Semikolon (;)** als Trennzeichen.

### ----------------------------
### Schritt 3: Daten importieren
### ----------------------------

Starte den Import-Vorgang für die neuen Mitarbeiter:

npm run import