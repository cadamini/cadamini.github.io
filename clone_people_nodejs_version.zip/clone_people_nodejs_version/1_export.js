const axios = require('axios');
const fs = require('fs');
const { stringify } = require('csv-stringify/sync');

require('dotenv').config();


// --- Configuration ---
const API_TOKEN = process.env.API_TOKEN;
const TEMPLATE_PERSON_ID = process.env.TEMPLATE_PERSON_ID;
const BASE_URL = "https://api.peopleware.com";
const IMPORT_FILE = process.env.IMPORT_FILE;

const headers = {
    'Authorization': `Bearer ${API_TOKEN}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
};

async function getTemplateData() {
    console.log(`Sammle Vorlagen-Daten für Person ${TEMPLATE_PERSON_ID}...`);

    const endpoints = {
        contracts: `/people/${TEMPLATE_PERSON_ID}/contract-assignments`,
        units: `/people/${TEMPLATE_PERSON_ID}/planning-unit-memberships`,
        skills: `/people/${TEMPLATE_PERSON_ID}/skill-level-assignments`,
        selectors: `/people/${TEMPLATE_PERSON_ID}/selection-memberships`,
        wtp: `/people/${TEMPLATE_PERSON_ID}/work-time-pattern-model-assignments`,
        shift_seq: `/people/${TEMPLATE_PERSON_ID}/shift-sequence-assignments`
    };

    const results = {};

    for (const [key, path] of Object.entries(endpoints)) {
      try {
          const resp = await axios.get(`${BASE_URL}${path}`, { headers });
          results[key] = resp.data.data;
      } catch (e) {
          if (e.response && e.response.status === 401) {
              console.error(`\n🔴 401 Unauthorized.`);
              console.error(`Das in API_TOKEN eingegebene Token ist ungültig oder abgelaufen. Bitte prüfe die Konfiguration im Script.`);
              process.exit(1); // Stoppt das gesamte Skript sofort
          }
          
          console.error(`Warnung: Konnte ${key} nicht laden. Pfad: ${path}`);
          results[key] = [];
      }
  }
    const csvContent = stringify([
        ["firstName", "lastName", "email", "personnelNumber", "json_contracts", "json_units", "json_skills", "json_selectors", "json_wtp", "json_shift_seq"],
        [
            "Vorname", "Nachname", "email@company.de", "PERS-001",
            JSON.stringify(results.contracts),
            JSON.stringify(results.units),
            JSON.stringify(results.skills),
            JSON.stringify(results.selectors),
            JSON.stringify(results.wtp),
            JSON.stringify(results.shift_seq)
        ]
    ], { delimiter: ';' });

    fs.writeFileSync(IMPORT_FILE, csvContent);
    console.log(`\n✅ Datei '${IMPORT_FILE}' wurde erstellt.`);
    console.log("Öffne diese Semikolon-getrennte CSV-Datei 'import.csv' in Excel und kopiere Zeile 2 für weitere neue Mitarbeiter. Passe dann nur Spalte 1-5 an, die JSON-Spalten (6-11) sollten unverändert bleiben, damit der Import später reibungslos funktioniert.");
}

getTemplateData();